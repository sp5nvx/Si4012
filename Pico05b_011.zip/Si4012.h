// Si4012.h 
// v1.5
//

#ifndef _SI4012_h
#define _SI4012_h


 #if defined(ARDUINO) && ARDUINO >= 100
	#include "Arduino.h"
 #else
	#include "WProgram.h"
 #endif


/****************************************************************************
 *  Si4012 tools by SP5NVX 
 *  v. 1.0 (2014)
 *  sp5nvx@wp.pl
 ****************************************************************************/
#include <Wire.h>
#include <stdarg.h>


/****************************************************************************
 *  Global Macros & Definitions
 ****************************************************************************/
/*
/////// Macro tools for bits (set and clear) 
#define BIT(x) (1 << (x)) 
#define SETBITS(x,y) ((x) |= (y)) 
#define CLEARBITS(x,y) ((x) &= (~(y))) 
#define SETBIT(x,y) SETBITS((x), (BIT((y)))) 
#define CLEARBIT(x,y) CLEARBITS((x), (BIT((y)))) 
#define BITSET(x,y) ((x) & (BIT(y))) 
#define BITCLEAR(x,y) !BITSET((x), (y)) 
#define BITSSET(x,y) (((x) & (y)) == (y)) 
#define BITSCLEAR(x,y) (((x) & (y)) == 0) 
#define BITVAL(x,y) (((x)>>(y)) & 1) 
*/
/////// ***************************
/////// COMMAND: CHANGE_STATE    
#define MODE2 4, 0x60            
/////// ***************************
#define Idle1 0x00
#define Shutdown1 0x01
// --------------------------------
#define Standby2 0x00
#define Sensor2 0x01
#define Tune2 0x02

/////// ***************************
/////// PROPERTY: TUNE_INTERVAL
#define TUNE1INT 5, 0x11, 0x21
/////// ***************************
#define Tune1Sec2 0x00, 0x2
#define Tune1Sec10 0x00, 0x0A
#define Tune1Sec60 0x00, 0x3C

/////// ***************************
/////// PROPERTY: MODULATION_FSKDEV
#define MODUL2DEV 5, 0x11, 0x20
/////// ***************************
#define Ook1 0x00
#define Fsk1 0x01
// --------------------------------  
#define Fsk2Dev1ppm 0x01 
#define Fsk2Dev2ppm 0x02												   // FSK dev [ppm] http://www.jittertime.com/resources/ppmcalc.shtml 
#define Fsk2Dev3ppm 0x03
#define Fsk2Dev4ppm 0x04
#define Fsk2Dev5ppm 0x05
/////// ***************************
/////// PROPERTY: CHIP_CONFIG
#define CHIP1CONFIG 4, 0x11, 0x10
/////// ***************************
#define UseXo1LsbFirst 0x0C
#define NoXo1LsbFirst 0x04

/////// ***************************
/////// PROPERTY: TX_FREQ
#define TX1FREQ 7, 0x11, 0x40
/* uint32_t to 4 bytes data tools macro */ 
 #define _U4BYTE1(w) ((unsigned char)(((uint32_t)(w) >> 24) & 0xFF)) 
 #define _U4BYTE2(w) ((unsigned char)(((uint32_t)(w) >> 16) & 0xFF))
 #define _U4BYTE3(w) ((unsigned char)(((uint32_t)(w) >>  8) & 0xFF))
 #define _U4BYTE4(w) ((unsigned char)(((uint32_t)(w) >>  0) & 0xFF))
#define Tx1Freq(hz)  _U4BYTE1(hz), _U4BYTE2(hz), _U4BYTE3(hz), _U4BYTE4(hz)

/////// ***************************
/////// PROPERTY: BITRATE_CONFIG 
#define BITRATE2CONFIG 6, 0x11, 0x31
/////// ***************************
/* uint16_t to 2 bytes data tools macro */
 #define _U2BYTE1(u) ((unsigned char)(((uint16_t)(u) >>  8) & 0xFF))
 #define _U2BYTE2(u) ((unsigned char)(((uint16_t)(u) >>  0) & 0xFF))
#define Data1Rate(i)  _U2BYTE1(i), _U2BYTE2(i)                             // In units of 100 bps, 1..1000 FSK 1..500 OOK
// -------------------------------- 
#define Ramp2Rate1us 0x01                                                  // Ramp rate in �s. 1, 2, 4, or 8 is supported, default 2
#define Ramp2Rate2us 0x02
#define Ramp2Rate4us 0x04
#define Ramp2Rate8us 0x08

/////// ***************************
/////// PROPERTY: XO_CONFIG
#define XO2CONFIG 8, 0x11, 0x50
/////// ***************************
#define Xo1Freq(hz)  _U4BYTE1(hz), _U4BYTE2(hz), _U4BYTE3(hz), _U4BYTE4(hz) // 10-13MHz
// --------------------------------
#define Xo2LowCapMore14pF 0x00                   // Cload > 14 pF
#define Xo2LowCapLess14pF 0x01

/////// ***************************
/////// PROPERTY: PA_CONFIG
#define PA5CONFIG 9, 0x11, 0x60                  // Read Si4012 calculator spreadsheet AN564                                                            
/////// ***************************#define Pa1MaxDrv0 0x00#define Pa1MaxDrv1 0x01                          // Default// --------------------------------#define Pa2Level0 0x20            #define Pa2Level1 0x40           #define Pa2Level2 0x60#define Pa2Level3 0x7F                           // Max// --------------------------------#define Pa3Cap(c) _U2BYTE1(c), _U2BYTE2(c)       // Default 128   max 511// --------------------------------
#define f4AlphaSteps(s) _U2BYTE2(s)              // Default 125   (0..250) // --------------------------------#define f5BetaSteps(s) _U2BYTE2(s)               // Default 127   (0..254)
/////// ***************************
/////// PROPERTY: FIFO_THRESHOLD
#define FIFO3THRESHOLD 6, 0x11, 0x30
/////// ***************************
#define Almost1Full(b) _U2BYTE2(b)               // Almost Full Threshold in bytes, default 0xF0
// ---------------------------
#define Almost2Empty(b) _U2BYTE2(b)              // Almost Empty Threshold in bytes, default 0x10
// ---------------------------
#define Thres3Control(b) _U2BYTE2(b)             // Threshold, when to start auto transmit, default 0x20

/////// ***************************
/////// COMMAND: SET_INT FIFO_INT
#define FIFO1INTERRUPTS 3, 0x63/////// ***************************              //B11111110#define Enable1int(bin) _U2BYTE2(bin)            //Underflow,Full,Empty,Overflow,PacketSent,LowBatt,1(tune),reserved#define BTB(v,i) ((v) & (1u << (i))) ? true : false
class SI4012 : public TwoWire{private:    char* msg;	int   len;	bool  clr;		int   c_w;                                 // count, data in fifo	int   c_p;                                 // count, bytes data in fifo	int   c_r;                                 // count, tx repeat	int SetFIFO(int from, int to, bool clear);public:    SI4012(int);	~SI4012();    void Data();	int SetRadio(int nargs, ...);    void ClearFIFO();    void AddData(char* msg);	int TX_Start(int32_t size, bool autotx, int mode);	int GetIntStatus();	bool FIFO_empty(); };

#endif

