// Si4012.cpp
// v1.5
// 

extern "C" {
  #include <stdarg.h> 
}

#include "Si4012.h"
#include <Wire.h>




SI4012::SI4012(int _len)
{
	msg=NULL;
	len = _len;
	clr = false;
	c_w = 0;   // count data in fifo
	c_p = 0;   // count pump (add) data to fifo
	c_r = 0;   // count tx data
}

SI4012::~SI4012()
{
	//if(msg!=0)
		//free(msg);
}
void SI4012::ClearFIFO()
{
    clr = false; // not clear
}
void SI4012::Data()
{  	
	if(c_p>=c_r) {c_p=0;return;}	            // no more data?

	c_w = SetFIFO(0,23,false);                  // loading data, some error in SetFIFO(...) but working partially for 23 bytes   
	c_w+= SetFIFO(24,47,false);        
	c_w+= SetFIFO(48,71,false);	
	c_w+= SetFIFO(72,95,false);
	
	c_p++;
		
}
bool SI4012::FIFO_empty()
{
	if(c_p==0) 
		return true;

    return false;
}
void SI4012::AddData(char* _msg)
{
	if(!clr){
		SetFIFO(0,0,true);
		clr = true;
		c_w = 0;
	}
    
    //if(msg!=0)
		//free(msg);
	//msg = (char*)malloc(sizeof(char)*len);
    //if(_msg!=0)
	   //strcpy(msg,_msg);
	msg=_msg;
	Data();
}
int SI4012::GetIntStatus()
{		
	int INT_STATUS=0;
	// COMMAND: GET_INT_STATUS
    Wire.beginTransmission(B1110000); // transmit to device 1110000
    Wire.write(0x64);                 // cmmand GET_INT_STATUS
	Wire.endTransmission();           // stop transmitting
    delayMicroseconds(2);
	Wire.requestFrom(B1110000, 2);    // request 2 bytes
    while(Wire.available())           // slave may send less than requested
    {                                 // read status byte
	   if(Wire.read()==128){
          INT_STATUS = Wire.read();           
	   }else return -1;
	}
	
	//if(BTB(INT_STATUS,7)){ }
	//if(BTB(INT_STATUS,6)){ }                 // Almost Full
	if(BTB(INT_STATUS,5)){ Data(); return 5;}  // Almost Empty
	//if(BTB(INT_STATUS,4)){ }                 // FIFO Overflow
	//if(BTB(INT_STATUS,3)){ }
	//if(BTB(INT_STATUS,2)){ }
	//if(BTB(INT_STATUS,1)){ }
	//if(BTB(INT_STATUS,0)){ }
    
	/* 7 iffunder�FIFO Underflow
       6 itxffafull�TX FIFO Almost Full
       5 itxffaem�TX FIFO Almost Empty    
       4 iffover�FIFO Overflow              (po za�adowaniu ponad 255 bytes)           
       3 ipksent�Packet Sent
       2 ilbd�Low Battery Detect
       1 itune�tune complete                (po ramce zapala si� z lekkim op�nieniem)
       0 ipor�Power On Reset
	*/	
	
	return 0;
}


int SI4012::TX_Start(int32_t size, bool autotx, int mode)
{   
	c_r = size;
	size=(size*c_w);
    int a = 0;
	if(autotx) a=4;
	unsigned char bytes[2];
    bytes[0] = (size >>  8) & 0xFF;
    bytes[1] =  size        & 0xFF;

    Wire.beginTransmission(B1110000); // transmit to device 1110000
    Wire.write(0x62);                 // cmmand TX
	Wire.write(bytes[0]);             // packet size 
    Wire.write(bytes[1]);             // packet size            
	Wire.write(a);                    // AutoTX State    4 - AutoTX and idle state after
    Wire.write(0);                    // idle mode 0 or sensor 1
    Wire.write(mode);                 // DTMod: FIFO 0 CW 1 Test: 2 i 3 <------- mode !!! ///
	Wire.endTransmission();           // stop transmitting
    delayMicroseconds(2);
	Wire.requestFrom(B1110000, 2);    // request 2 bytes
    while(Wire.available())           // slave may send less than requested
    { 
       int st = Wire.read();          // read status byte
	   int s  = Wire.read();          // not sent packet size
	   if(st!=128)
		   return -1;
	   else return s;                 // ok
	}	
	return -1;
}


int SI4012::SetRadio(int nargs, ...)
{	
	
	int b = 0; 
	int DEVICE_ADR = 112;             // I2C Si4012 Adr B1110000
	va_list arglist;
	va_start(arglist, nargs); 
	Wire.beginTransmission(DEVICE_ADR); 
	for(int n = 1; n < nargs; n++) {        		  
		Wire.write(va_arg(arglist, int)); 
	}	
	Wire.endTransmission();           // stop transmitting
    va_end(arglist);
	delayMicroseconds(2);
	
	Wire.requestFrom(DEVICE_ADR, 1);  // request 1 byte
    while(Wire.available())           // slave may send less than requested
    {   
       byte st = Wire.read();         // read status byte 19 err codes
	   if(st!=128){ 
		   
		   return -1;
	   }
	   else return nargs;             // ok
	}
	return -1;                        // no response	    
}




int SI4012::SetFIFO(int from, int to, bool clear)
{		
    int Count=0;
	int w=0;
	if(clear){
	 delayMicroseconds(2);
	 Wire.beginTransmission(B1110000); // transmit to device 1110000
     Wire.write(0x65);                 // cmmand FiFo Clear
     Wire.endTransmission();       
     delayMicroseconds(2);
     Wire.requestFrom(B1110000, 1);    // request 1 byte
     while(Wire.available())           // slave may send less than requested
     {                                 // read status byte
	   if(Wire.read()!=128)
		   return -1;
	 }
	}
    if(from==0 && to==0) return 0;

	if(msg==NULL) return -2;

    Wire.beginTransmission(B1110000); // transmit to device 1110000
    Wire.write(0x66);                 // cmmand FiFo Set
	byte c = 0;                       // 7N1 
	int b = 0;                        // bits 0..7 of c (out byte) 
	int i = from;                     // i chars 0..len-1
	int n = 0;                        // bits 0..6 of msg[] data
	do{    
                                      // set nth bit n 0..6
		if(n==0){                     // before msg[i] char
		   c &= ~(1u << b);           // set start bit 0
		   b++; 
		}		
		if(b>7) {b=0;w+=Wire.write(c);c=0;Count++;}
        
        if(!(i>=len || i>=strlen(msg)))
		   if(BTB(msg[i],n)) c |= (1u << b);
		               else  c &= ~(1u << b);
	 	b++;                          // next bit of out   
		if(b>7) {b=0;w+=Wire.write(c);c=0;Count++;} 
		n++;		                  // next bit of msg[i]
		if(n>6)                       // finish msg[i] char
		{
			c |= (1u << b);           // stop bit 1
			b++;
			
			if(b>7) {b=0;w+=Wire.write(c);c=0;Count++;}
            
			c |= (1u << b);           // stop bit 2
			b++;
            
			n=0;
			i++;                      // next msg[i] char
		}                 
	    if(b>7) {b=0;w+=Wire.write(c);c=0;Count++;} 
		delayMicroseconds(25);
	}while(i<to+1);	

	
    Wire.endTransmission();       
    delayMicroseconds(2);
    Wire.requestFrom(B1110000, 1);    // request 1 byte
    while(Wire.available())           // slave may send less than requested
    { 		
       int st = Wire.read();          // read status byte
	   if(st!=128)
		   return -1;
	}    	
	return w;
}

